#!/bin/bash
# ═══════════════════════════════════════════════════════════
# 🚀 Ultimate Telegram Game Bot - Installation Script
# ═══════════════════════════════════════════════════════════

set -e

echo "╔═══════════════════════════════════════════════════════╗"
echo "║   🎮 Ultimate Telegram Game Bot Installer            ║"
echo "╚═══════════════════════════════════════════════════════╝"
echo ""

# Update & Install
echo "📦 Installing dependencies..."
sudo apt update -y
sudo apt install -y python3.11 python3.11-venv python3-pip

# Virtual Environment
echo "🐍 Setting up virtual environment..."
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Directories
echo "📁 Creating directories..."
mkdir -p data logs assets backups

# Configuration
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✅ .env created. Please edit it: nano .env"
fi

chmod +x bot.py
chmod -R 755 assets/

echo ""
echo "✅ Installation complete!"
echo "Run: python bot.py"
