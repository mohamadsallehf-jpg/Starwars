# -*- coding: utf-8 -*-
"""
⚙️ تنظیمات مرکزی ربات
🔧 همه تنظیمات را اینجا ویرایش کنید
"""
import os

# ════════════════════════════════════════════
#  🔑 توکن و آیدی‌های اصلی
# ════════════════════════════════════════════
TOKEN      = os.environ.get("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
ADMIN_IDS  = list(map(int, os.environ.get("ADMIN_IDS", "123456789").split(",")))
MAIN_GROUP = int(os.environ.get("MAIN_GROUP", "0"))    # آیدی عددی گروه (منفی)
GROUP_LINK = os.environ.get("GROUP_LINK", "https://t.me/your_group")
GROUP_NAME = os.environ.get("GROUP_NAME", "گروه بازی")

# ════════════════════════════════════════════
#  📁 مسیرها
# ════════════════════════════════════════════
DB_FILE     = "data/game.db"
ASSETS_DIR  = "assets"
LOG_FILE    = "logs/bot.log"

# ════════════════════════════════════════════
#  💰 اقتصاد
# ════════════════════════════════════════════
START_BALANCE   = 500_000
USD_PRICE       = 83_750
MAX_USD         = 400
STONE_PRICE     = 5_000
WOOD_PRICE      = 5_000
RUBY_RATE       = 350

# ════════════════════════════════════════════
#  👥 رفرال
# ════════════════════════════════════════════
REF_INVITER  = 5_000
REF_NEW      = 2_000

# ════════════════════════════════════════════
#  ⚔️ شرط‌بندی دو نفره
# ════════════════════════════════════════════
BET2_MIN    = 10_000
BET2_MAX    = 50_000_000
BET2_EXPIRE = 120   # ثانیه

# ════════════════════════════════════════════
#  ⏱️ کول‌داون‌ها (ثانیه)
# ════════════════════════════════════════════
CD = {
    "coin":          1800,
    "daily":         86400,
    "break":         3600,
    "break_victim":  3600,
    "charity":       1800,
    "givecharity":   1800,
    "hakbank":       10800,
    "tax":           3600,
    "afghani_pay":   3600,
    "stone_collect": 7200,
    "wood_collect":  7200,
    "attack":        300,
    "setjob":        86400,
    "tas":           600,
    "slot":          1800,
    "bowling":       600,
    "football":      600,
    "dart":          600,
    "basketball":    600,
    "mine":          3600,
}
