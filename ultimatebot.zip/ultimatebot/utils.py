# -*- coding: utf-8 -*-
"""
🛠️ Utility Functions - Helper Functions
توابع کمکی و یوتیلیتی
"""
import os, time
from io import BytesIO
from typing import Optional

# ══════════ Assets ══════════
ASSETS = {}

def load_assets():
    """بارگذاری تمام تصاویر"""
    global ASSETS
    asset_list = [
        'welcome', 'win', 'win_vip', 'lose', 'lose_vip',
        'market', 'leaderboard', 'help', 'arsenal', 'bet',
        'jobs', 'profile', 'admin', 'attack', 'economy',
        'military', 'luckbox', 'referral'
    ]
    
    for name in asset_list:
        path = os.path.join('assets', f'{name}.jpg')
        if os.path.exists(path):
            with open(path, 'rb') as f:
                ASSETS[name] = f.read()

def get_img(key: str) -> Optional[BytesIO]:
    """دریافت تصویر به صورت BytesIO"""
    data = ASSETS.get(key)
    if not data:
        return None
    buf = BytesIO(data)
    buf.name = f"{key}.jpg"
    buf.seek(0)
    return buf

# ══════════ Formatting ══════════
def fmt(n) -> str:
    """فرمت اعداد با کاما"""
    try:
        return f"{int(n):,}"
    except:
        return str(n)

def fmt_cd(seconds: int) -> str:
    """فرمت کول‌داون"""
    h, m, s = abs(seconds)//3600, (abs(seconds)%3600)//60, abs(seconds)%60
    if h > 0:
        return f"{h:02}:{m:02}:{s:02}"
    return f"{m:02}:{s:02}"

def progress_bar(current, maximum, length=10) -> str:
    """نوار پیشرفت ساده"""
    filled = int((current / maximum) * length) if maximum > 0 else 0
    return "█" * filled + "░" * (length - filled)

# ══════════ VIP ══════════
def is_vip(player: dict) -> bool:
    """بررسی VIP بودن"""
    return bool(player.get('vip')) and (
        player.get('vip_until', 0) > time.time() or 
        player.get('vip_until', 0) == -1
    )

def vip_bonus(player: dict, base: int) -> int:
    """محاسبه بونوس VIP"""
    return int(base * 2) if is_vip(player) else base

# ══════════ Send Message Helper ══════════
async def send_with_image(message, text, image_key=None, keyboard=None, parse_mode="Markdown"):
    """ارسال پیام با یا بدون تصویر"""
    img = get_img(image_key) if image_key else None
    
    try:
        if img and hasattr(message, 'reply_photo'):
            return await message.reply_photo(
                photo=img,
                caption=text,
                parse_mode=parse_mode,
                reply_markup=keyboard
            )
        elif hasattr(message, 'reply_text'):
            return await message.reply_text(
                text,
                parse_mode=parse_mode,
                reply_markup=keyboard
            )
    except Exception:
        if hasattr(message, 'reply_text'):
            return await message.reply_text(text, parse_mode=parse_mode, reply_markup=keyboard)

async def edit_with_image(query, text, image_key=None, keyboard=None, parse_mode="Markdown"):
    """ویرایش پیام callback"""
    try:
        if query.message.photo and image_key:
            await query.edit_message_caption(
                caption=text,
                parse_mode=parse_mode,
                reply_markup=keyboard
            )
        else:
            await query.edit_message_text(
                text,
                parse_mode=parse_mode,
                reply_markup=keyboard
            )
    except:
        pass

# ══════════ Validation ══════════
def validate_amount(text: str) -> Optional[int]:
    """اعتبارسنجی مبلغ"""
    try:
        amount = int(text)
        return amount if amount > 0 else None
    except:
        return None

def validate_username(text: str) -> bool:
    """اعتبارسنجی نام کاربری"""
    if not text:
        return False
    text = text.lstrip('@')
    return text.isalnum() and len(text) >= 4

# ══════════ Time ══════════
def time_ago(timestamp: int) -> str:
    """زمان گذشته"""
    diff = int(time.time()) - timestamp
    
    if diff < 60:
        return f"{diff} ثانیه پیش"
    elif diff < 3600:
        return f"{diff//60} دقیقه پیش"
    elif diff < 86400:
        return f"{diff//3600} ساعت پیش"
    else:
        return f"{diff//86400} روز پیش"

# ══════════ Random ══════════
def random_choice_weighted(choices: list, weights: list):
    """انتخاب تصادفی با وزن"""
    import random
    return random.choices(choices, weights=weights, k=1)[0]
