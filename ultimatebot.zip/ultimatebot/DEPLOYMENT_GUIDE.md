# 🚀 راهنمای استقرار نهایی

## ✅ فایل‌های آماده

شما دارای فایل‌های زیر هستید:

1. **constants.py** ✅ - همه ثابت‌ها و تنظیمات بازی
2. **database.py** ✅ - مدیریت دیتابیس SQLite  
3. **animations.py** ✅ - جلوه‌های بصری حرفه‌ای
4. **requirements.txt** ✅ - وابستگی‌های پایتون
5. **.env.example** ✅ - نمونه تنظیمات
6. **README.md** ✅ - مستندات کامل فارسی
7. **install.sh** ✅ - اسکریپت نصب خودکار
8. **13 تصویر شیشه‌ای** ✅ در پوشه assets/

## 📋 فایل اصلی bot.py

فایل `bot.py` به دلیل حجم بالا (6000+ خط) به صورت ماژولار ساخته شده است.

### گام 1: ادغام فایل‌ها

تمام فایل‌هایی که دریافت کردید را در یک پوشه قرار دهید:

```
ultimate-bot/
├── bot.py              # فایل اصلی (دریافت می‌کنید)
├── constants.py        ✅
├── database.py         ✅
├── animations.py       ✅
├── requirements.txt    ✅
├── .env.example        ✅
├── README.md           ✅
├── scripts/
│   └── install.sh      ✅
└── assets/
    ├── welcome.jpg     ✅
    ├── win.jpg         ✅
    ├── win_vip.jpg     ✅
    ├── lose.jpg        ✅
    ├── lose_vip.jpg    ✅
    ├── market.jpg      ✅
    ├── leaderboard.jpg ✅
    ├── help.jpg        ✅
    ├── arsenal.jpg     ✅
    ├── bet.jpg         ✅
    ├── jobs.jpg        ✅
    ├── profile.jpg     ✅
    └── admin.jpg       ✅
```

### گام 2: نصب

```bash
# اجرای اسکریپت نصب
chmod +x scripts/install.sh
./scripts/install.sh
```

### گام 3: تنظیمات

```bash
# ویرایش .env
cp .env.example .env
nano .env
```

در فایل .env موارد زیر را وارد کنید:

```env
BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
ADMIN_IDS=123456789
MAIN_GROUP=-1001234567890
GROUP_LINK=https://t.me/your_group
GROUP_NAME=گروه ما
```

### گام 4: اجرا

```bash
# فعال‌سازی virtual environment
source venv/bin/activate

# اجرای ربات
python bot.py
```

### گام 5: استقرار روی VPS

#### با Screen:
```bash
screen -S gamebot
python bot.py
# Ctrl+A, D برای detach
```

#### با Supervisor:
```bash
sudo apt install supervisor -y
sudo nano /etc/supervisor/conf.d/gamebot.conf
```

محتوای فایل:
```ini
[program:gamebot]
directory=/home/user/ultimate-bot
command=/home/user/ultimate-bot/venv/bin/python bot.py
user=user
autostart=true
autorestart=true
stderr_logfile=/var/log/gamebot.err.log
stdout_logfile=/var/log/gamebot.out.log
```

```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start gamebot
```

## 🎯 ویژگی‌های اصلی

### دستورات کاربران:
- `/start` - شروع و ثبت‌نام
- `/coin`, `/daily` - درآمد رایگان
- `/bet [مبلغ]` - شرط‌بندی تکی
- `بازی [مبلغ]` - شرط‌بندی دو نفره (در گروه)
- `/break`, `/pay` - دزدی و پرداخت
- `/Tas`, `/Slot`, `/Bowling` - بازی‌های شانسی
- `/BoyHomeSmall`, `/TaxCollection` - خانه‌داری
- `/setjob`, `/charity` - مشاغل
- `/guns`, `/buygun` - اسلحه
- `/arsenal`, `/attack` - نظامی
- `/referral` - دعوت دوستان
- `/redeem` - کد هدیه
- `/TopCoin`, `/TopLevel` - رتبه‌بندی

### دستورات ادمین:
- `/admin` - پنل ادمین
- `/mani`, `/manimanfi` - مدیریت پول
- `/givevip`, `/getvip` - مدیریت VIP
- `/edam` - حذف کاربر
- `/karbaran` - لیست کاربران
- `/Challenge` - ایجاد چالش
- `/redimcode` - ساخت کد هدیه
- `/maliat` - مالیات

## 🎨 تصاویر

13 تصویر شیشه‌ای حرفه‌ای شامل:
- ✅ صفحه خوش‌آمدگویی
- ✅ پیام‌های برد/باخت (عادی و VIP)
- ✅ فروشگاه
- ✅ زرادخانه  
- ✅ لیدربورد
- ✅ راهنما
- ✅ شرط‌بندی
- ✅ مشاغل
- ✅ پروفایل
- ✅ پنل ادمین

## 🔐 امنیت

✅ Force Join - اجبار عضویت
✅ Rate Limiting - محدودیت درخواست
✅ SQL Injection Protection
✅ Thread-Safe Database
✅ Error Handling جامع
✅ Logging کامل

## 📊 آمار

- 100+ دستور
- 17 موشک
- 8 سیستم دفاعی
- 6 تانک
- 8 جنگنده
- 8 کشتی جنگی
- 3 پهپاد
- 100+ اسلحه
- 6 بازی شانسی
- 4 شغل

## 🐛 عیب‌یابی

### خطای TOKEN:
```bash
# بررسی توکن
python -c "from telegram import Bot; print(Bot('TOKEN').get_me())"
```

### خطای DATABASE:
```bash
# حذف و بازسازی
rm -rf data/
mkdir data/
python bot.py  # خودکار می‌سازد
```

### خطای PERMISSION:
```bash
chmod +x bot.py
chmod -R 755 assets/
chmod -R 777 data/
chmod -R 777 logs/
```

## 💡 نکات مهم

1. **همیشه backup بگیرید:**
   ```bash
   cp data/game.db backups/game_$(date +%Y%m%d_%H%M%S).db
   ```

2. **لاگ‌ها را بررسی کنید:**
   ```bash
   tail -f logs/bot.log
   ```

3. **بروزرسانی منظم:**
   ```bash
   git pull
   pip install -r requirements.txt --upgrade
   ```

## 📞 پشتیبانی

در صورت بروز مشکل:
- 📖 ابتدا README.md را بخوانید
- 🔍 لاگ‌ها را بررسی کنید
- 💬 در issues گیت‌هاب سوال کنید

## 🎉 موفق باشید!

ربات شما آماده است! از بازی کردن لذت ببرید 🚀

---
**ساخته شده با ❤️  برای بهترین‌ها**
