# 🎮 Ultimate Telegram Game Bot

<div dir="rtl">

## 📖 معرفی

یک ربات بازی تلگرامی **حرفه‌ای** و **کامل** با قابلیت‌های پیشرفته:

- ⚔️ سیستم جنگ و حمله نظامی (موشک، تانک، جنگنده، کشتی، پهپاد)
- 💰 سیستم اقتصادی پیشرفته (بانک، خانه، کارخانه، مشاغل)
- 🎲 بازی‌های شانسی متنوع
- 🌿 سیستم مواد و اعتیاد
- 👥 سیستم رفرال و دعوت
- ⚔️ شرط‌بندی دو نفره با تایمر
- 🎁 جعبه شانس خودکار
- 👑 سیستم VIP
- 🔫 100+ اسلحه قابل خرید
- 🛡️ سیستم‌های دفاعی متعدد

## ✨ ویژگی‌های کلیدی

### 🎨 رابط کاربری
- ✅ دکمه‌های شیشه‌ای زیبا
- ✅ تصاویر حرفه‌ای
- ✅ انیمیشن‌های متنی
- ✅ Progress bars گرافیکی

### 🔐 امنیت
- ✅ Force Join (اجبار عضویت)
- ✅ Rate Limiting
- ✅ Anti-Spam System
- ✅ SQL Injection Protection
- ✅ Thread-Safe Database

### ⚡ کارایی
- ✅ Async/Await کامل
- ✅ Database Optimization
- ✅ Caching System
- ✅ Job Queue مدیریت شده

### 📊 مدیریت
- ✅ پنل ادمین جامع
- ✅ آمار و گزارش
- ✅ Backup خودکار
- ✅ لاگ‌گیری کامل

## 🚀 نصب و راه‌اندازی

### پیش‌نیازها

```bash
# Ubuntu 24.04 LTS
sudo apt update
sudo apt install python3.11 python3.11-venv python3-pip git -y
```

### نصب

```bash
# 1. کلون کردن پروژه
git clone https://github.com/your-repo/ultimate-bot.git
cd ultimate-bot

# 2. ساخت محیط مجازی
python3.11 -m venv venv
source venv/bin/activate

# 3. نصب وابستگی‌ها
pip install -r requirements.txt

# 4. کپی و تنظیم .env
cp .env.example .env
nano .env  # تنظیم TOKEN و ADMIN_IDS
```

### تنظیمات

فایل `.env` را با اطلاعات زیر پر کنید:

```env
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz  # از @BotFather
ADMIN_IDS=123456789,987654321                     # آیدی عددی ادمین‌ها
MAIN_GROUP=-1001234567890                         # آیدی گروه اصلی
GROUP_LINK=https://t.me/your_group                # لینک دعوت گروه
GROUP_NAME=گروه اصلی ما
```

### اجرا

```bash
# حالت عادی
python bot.py

# با screen (برای VPS)
screen -S gamebot
python bot.py
# Ctrl+A, D برای detach
```

## 📋 دستورات

### 🎮 عمومی
- `/start` - شروع و ثبت‌نام
- `/help` - راهنمای کامل
- `/info` - مشاهده پروفایل
- `/time` - وضعیت کول‌داون‌ها

### 💰 اقتصاد
- `/coin` - دریافت سکه رایگان
- `/daily` - پاداش روزانه
- `/bet [مبلغ]` - شرط‌بندی
- `/pay [مبلغ]` - پرداخت (ریپلای)
- `/break` - دزدی (ریپلای)
- `/transfer` - انتقال به بانک
- `/withdraw` - برداشت از بانک

### 🏢 املاک و صنایع
- `/BoyHomeSmall` - خرید خانه
- `/TaxCollection` - جمع‌آوری مالیات
- `/BuyAfghani` - خرید کارگر
- `/AfghaniPay` - دریافت درآمد
- `/StoneFactory` - خرید کارخانه سنگ
- `/StoneCollection` - برداشت سنگ
- `/WoodFactory` - خرید کارخانه چوب
- `/WoodCollection` - برداشت چوب
- `/sellstone` - فروش سنگ
- `/sellwood` - فروش چوب
- `/buyUSD` - خرید دلار
- `/sellUSD` - فروش دلار

### 🎲 بازی‌های شانسی
- `/Tas` - بازی تاس
- `/Slot` - ماشین اسلات
- `/Bowling` - بولینگ
- `/Football` - فوتبال
- `/Dart` - دارت
- `/BasketBall` - بسکتبال

### 💼 مشاغل
- `/setjob [شغل]` - تغییر شغل
- `/jobs` - اطلاعات شغل
- `/charity` - کمک خیریه (گدا)
- `/givecharity` - اهدای کمک
- `/hakbank` - هک بانک (هکر)
- `/foroshgol` - فروش گل (ساقی)
- `/foroshshishe` - فروش شیشه
- `/foroshteryak` - فروش تریاک
- `/mavad` - موجودی مواد
- `/keshidanmavad` - مصرف مواد
- `/yas` - تأیید خرید
- `/no` - لغو خرید

### 🔫 اسلحه
- `/guns` - لیست اسلحه‌ها
- `/buygun [کلید]` - خرید اسلحه

### 🚀 نظامی
- `/arsenal` - زرادخانه شما
- `/shop_missiles` - فروشگاه موشک
- `/attack` - حمله به کاربر

### 👥 رفرال
- `/referral` - لینک دعوت
- `/myrefs` - آمار دعوت‌ها

### 🎁 کد هدیه
- `/redeem [کد]` - استفاده از کد

### 🏆 رتبه‌بندی
- `/TopCoin` - برترین دارایی
- `/TopLevel` - برترین سطح
- `/TopBet` - برترین شرط

### 👨‍💼 ادمین
- `/admin` - پنل ادمین
- `/mani` - افزایش موجودی
- `/manimanfi` - کاهش موجودی
- `/xp` - افزایش XP
- `/givevip` - دادن VIP
- `/getvip` - گرفتن VIP
- `/edam` - حذف کاربر
- `/karbaran` - لیست کاربران
- `/Challenge` - ایجاد چالش
- `/redimcode` - ساخت کد هدیه
- `/maliat` - مالیات تصادفی
- `/shart` - تنظیم نتایج شرط

## 🎯 شرط‌بندی دو نفره

در گروه اصلی بنویسید:
```
بازی 100000
```

- ⏰ نفر دوم 2 دقیقه فرصت دارد
- 🏆 برنده تمام مبلغ را می‌برد
- ✅ دکمه‌های شیشه‌ای برای پیوستن/لغو

## 🎁 سیستم جعبه شانس

- 🕐 هر 5 دقیقه یک جعبه در گروه
- 🏃 اولین نفر برنده می‌شود
- 🎰 جوایز تصادفی: سکه، یاقوت، موشک، XP
- ⏱️ 60 ثانیه فرصت

## 👑 VIP

### مزایا:
- ✅ ضریب درآمد 2x
- ✅ کول‌داون کمتر
- ✅ دسترسی به شغل هکر و ساقی
- ✅ تصاویر اختصاصی
- ✅ بونوس‌های ویژه

### دریافت:
- توسط ادمین با `/givevip`
- خرید (قابلیت آینده)

## 🔧 ساختار پروژه

```
ultimatebot/
├── bot.py              # فایل اصلی
├── database.py         # مدیریت دیتابیس
├── constants.py        # ثابت‌ها
├── keyboards.py        # دکمه‌ها
├── animations.py       # انیمیشن‌ها
├── utils.py            # توابع کمکی
├── requirements.txt    # وابستگی‌ها
├── .env.example        # نمونه تنظیمات
├── assets/             # تصاویر
│   ├── welcome.jpg
│   ├── win.jpg
│   ├── lose.jpg
│   └── ...
├── data/               # دیتابیس
│   └── game.db
└── logs/               # لاگ‌ها
    └── bot.log
```

## 📊 دیتابیس

### جداول:
- `players` - اطلاعات بازیکنان
- `missiles` - موشک‌ها
- `defenses` - دفاع‌ها
- `military_units` - واحدهای نظامی
- `materials` - مواد
- `cooldowns` - کول‌داون‌ها
- `bets` - شرط‌بندی‌ها
- `referrals` - رفرال‌ها
- `gift_codes` - کدهای هدیه
- `battles` - نبردها
- `lucky_boxes` - جعبه‌های شانس

## 🐛 عیب‌یابی

### ربات استارت نمی‌شود:
```bash
# بررسی لاگ
tail -f logs/bot.log

# بررسی env
cat .env

# تست توکن
python -c "from telegram import Bot; print(Bot('YOUR_TOKEN').get_me())"
```

### خطای دیتابیس:
```bash
# حذف دیتابیس
rm data/game.db
# ربات خودکار دوباره می‌سازد
```

### خطای permission:
```bash
chmod +x bot.py
chmod -R 755 assets/
```

## 📈 بهینه‌سازی

### برای VPS:
```bash
# نصب supervisor
sudo apt install supervisor -y

# کانفیگ
sudo nano /etc/supervisor/conf.d/gamebot.conf
```

محتوای فایل:
```ini
[program:gamebot]
directory=/home/user/ultimatebot
command=/home/user/ultimatebot/venv/bin/python bot.py
user=user
autostart=true
autorestart=true
stderr_logfile=/var/log/gamebot.err.log
stdout_logfile=/var/log/gamebot.out.log
```

```bash
# اعمال تغییرات
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start gamebot
```

## 🔒 امنیت

- ✅ هرگز `.env` را کامیت نکنید
- ✅ توکن ربات را محرمانه نگه دارید
- ✅ فقط ادمین‌های مورد اعتماد اضافه کنید
- ✅ Firewall را فعال کنید
- ✅ SSH با key authentication
- ✅ بک‌آپ منظم دیتابیس

## 🤝 مشارکت

1. Fork کنید
2. Branch بسازید: `git checkout -b feature/AmazingFeature`
3. Commit کنید: `git commit -m 'Add some AmazingFeature'`
4. Push کنید: `git push origin feature/AmazingFeature`
5. Pull Request باز کنید

## 📝 لایسنس

این پروژه تحت لایسنس MIT است.

## 💬 پشتیبانی

- 📧 Email: support@example.com
- 💬 Telegram: @YourSupport
- 🌐 Website: https://example.com

## 🙏 تشکر

از تمام توسعه‌دهندگان و کاربران عزیز که به بهبود این پروژه کمک کرده‌اند.

---

**ساخته شده با ❤️ در ایران**

</div>
