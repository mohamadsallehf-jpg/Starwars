# -*- coding: utf-8 -*-
"""🗄️ مدیریت دیتابیس SQLite - thread-safe کامل"""
import sqlite3, time, os, random, string, logging
from threading import Lock
from config import DB_FILE

log = logging.getLogger(__name__)
_lock = Lock()

def _conn():
    c = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA synchronous=NORMAL")
    return c

def init_db():
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    with _lock:
        c = _conn()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS players (
            id INTEGER PRIMARY KEY,
            username TEXT DEFAULT '',
            first_name TEXT DEFAULT '',
            referral_code TEXT UNIQUE,
            referred_by INTEGER DEFAULT 0,
            referrals_count INTEGER DEFAULT 0,
            -- اقتصاد
            balance INTEGER DEFAULT 500000,
            bank INTEGER DEFAULT 0,
            usd INTEGER DEFAULT 0,
            ruby INTEGER DEFAULT 50,
            cup INTEGER DEFAULT 100,
            toman INTEGER DEFAULT 5000,
            -- دارایی
            stone INTEGER DEFAULT 0,
            wood INTEGER DEFAULT 0,
            workers INTEGER DEFAULT 0,
            home_small INTEGER DEFAULT 0,
            stone_factory INTEGER DEFAULT 0,
            wood_factory INTEGER DEFAULT 0,
            -- شغل
            job TEXT DEFAULT 'ندارد',
            vip INTEGER DEFAULT 0,
            vip_until INTEGER DEFAULT 0,
            -- بازی
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            current_gun TEXT DEFAULT 'whip',
            addiction INTEGER DEFAULT 0,
            pending_buy TEXT DEFAULT '',
            -- نظامی
            level INTEGER DEFAULT 1,
            experience INTEGER DEFAULT 0,
            base_health INTEGER DEFAULT 100,
            shield INTEGER DEFAULT 0,
            guard_until INTEGER DEFAULT 0,
            -- زمان
            created_at INTEGER DEFAULT 0,
            last_login INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS guns_owned (
            player_id INTEGER, gun_key TEXT,
            PRIMARY KEY(player_id,gun_key),
            FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS missiles (
            player_id INTEGER, type TEXT, count INTEGER DEFAULT 0,
            PRIMARY KEY(player_id,type),
            FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS defenses (
            player_id INTEGER, type TEXT, level INTEGER DEFAULT 1, health INTEGER DEFAULT 100,
            PRIMARY KEY(player_id,type),
            FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS military_units (
            player_id INTEGER, category TEXT, type TEXT,
            count INTEGER DEFAULT 0, health INTEGER DEFAULT 100,
            PRIMARY KEY(player_id,category,type),
            FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS materials (
            player_id INTEGER, type TEXT, amount INTEGER DEFAULT 0,
            PRIMARY KEY(player_id,type),
            FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS cooldowns (
            player_id INTEGER, command TEXT, last_used INTEGER DEFAULT 0,
            PRIMARY KEY(player_id,command),
            FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS battles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            attacker_id INTEGER, defender_id INTEGER,
            weapon TEXT, damage INTEGER, stolen INTEGER DEFAULT 0,
            result TEXT, ts INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS gift_codes (
            code TEXT PRIMARY KEY,
            coins INTEGER DEFAULT 0, xp INTEGER DEFAULT 0, ruby INTEGER DEFAULT 0,
            uses_left INTEGER DEFAULT 1, max_uses INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS code_uses (
            code TEXT, player_id INTEGER, PRIMARY KEY(code,player_id)
        );
        CREATE TABLE IF NOT EXISTS bets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            creator_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            joiner_id INTEGER DEFAULT 0,
            winner_id INTEGER DEFAULT 0,
            chat_id INTEGER DEFAULT 0,
            msg_id INTEGER DEFAULT 0,
            created_at INTEGER DEFAULT 0,
            expires_at INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            referrer_id INTEGER NOT NULL,
            referred_id INTEGER NOT NULL UNIQUE,
            ts INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS lucky_boxes (
            box_id TEXT PRIMARY KEY,
            chat_id INTEGER, msg_id INTEGER,
            opened_by INTEGER DEFAULT 0,
            created_at INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS preplanned_bets (
            player_id INTEGER PRIMARY KEY, results TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bet_amount INTEGER DEFAULT 0, reward INTEGER DEFAULT 0,
            active INTEGER DEFAULT 0
        );
        """)
        c.commit(); c.close()
    log.info("✅ DB ready: %s", DB_FILE)

def q(sql, p=(), *, one=False, all_=False, run=False):
    with _lock:
        c = _conn()
        try:
            cur = c.execute(sql, p)
            if run:
                c.commit()
                return cur.lastrowid
            if one:
                r = cur.fetchone()
                return dict(r) if r else None
            if all_:
                return [dict(r) for r in cur.fetchall()]
        finally:
            c.close()

def tx(stmts):
    """چند عملیات در یک تراکنش"""
    with _lock:
        c = _conn()
        try:
            for sql, p in stmts:
                c.execute(sql, p)
            c.commit()
        except Exception as e:
            c.rollback(); raise e
        finally:
            c.close()

# ─── Player ─────────────────────────
def get_p(uid):
    return q("SELECT * FROM players WHERE id=?", (uid,), one=True)

def new_player(uid, username, first_name, ref_code=None):
    """True اگر کاربر جدید"""
    now = int(time.time())
    existing = get_p(uid)
    if existing:
        q("UPDATE players SET username=?,first_name=?,last_login=? WHERE id=?",
          (username,first_name,now,uid), run=True)
        return False
    rc = ''.join(random.choices(string.ascii_uppercase+string.digits, k=8))
    stmts = [
        ("INSERT OR IGNORE INTO players(id,username,first_name,referral_code,created_at,last_login) VALUES(?,?,?,?,?,?)",
         (uid,username,first_name,rc,now,now)),
        ("INSERT OR IGNORE INTO guns_owned(player_id,gun_key) VALUES(?,?)", (uid,'whip')),
        ("INSERT OR IGNORE INTO missiles(player_id,type,count) VALUES(?,?,?)", (uid,"فاتح",2)),
        ("INSERT OR IGNORE INTO missiles(player_id,type,count) VALUES(?,?,?)", (uid,"عماد",1)),
        ("INSERT OR IGNORE INTO defenses(player_id,type,level,health) VALUES(?,?,?,?)", (uid,"پدافند",1,100)),
    ]
    if ref_code:
        referrer = q("SELECT id FROM players WHERE referral_code=?", (ref_code,), one=True)
        if referrer and referrer['id'] != uid:
            rid = referrer['id']
            stmts += [
                ("UPDATE players SET balance=balance+5000,referrals_count=referrals_count+1 WHERE id=?", (rid,)),
                ("UPDATE players SET balance=balance+2000,referred_by=? WHERE id=?", (rid,uid)),
                ("INSERT OR IGNORE INTO referrals(referrer_id,referred_id,ts) VALUES(?,?,?)", (rid,uid,now)),
            ]
    tx(stmts)
    return True

def upd(uid, **kw):
    if not kw: return
    cols = ", ".join(f"{k}=?" for k in kw)
    q(f"UPDATE players SET {cols} WHERE id=?", (*kw.values(),uid), run=True)

def del_player(uid):
    for t in ["cooldowns","guns_owned","missiles","defenses","military_units","materials","preplanned_bets"]:
        q(f"DELETE FROM {t} WHERE player_id=?", (uid,), run=True)
    q("DELETE FROM players WHERE id=?", (uid,), run=True)

# ─── Cooldown ────────────────────────
def chk_cd(uid, cmd, secs):
    r = q("SELECT last_used FROM cooldowns WHERE player_id=? AND command=?", (uid,cmd), one=True)
    if not r: return True, 0
    el = time.time() - r['last_used']
    return (True,0) if el >= secs else (False, int(secs-el))

def set_cd(uid, cmd):
    q("INSERT OR REPLACE INTO cooldowns(player_id,command,last_used) VALUES(?,?,?)",
      (uid,cmd,int(time.time())), run=True)

# ─── Materials ───────────────────────
def get_mat(uid, t):
    r = q("SELECT amount FROM materials WHERE player_id=? AND type=?", (uid,t), one=True)
    return r['amount'] if r else 0

def set_mat(uid, t, amt):
    q("INSERT OR REPLACE INTO materials(player_id,type,amount) VALUES(?,?,?)", (uid,t,amt), run=True)

# ─── Bets ────────────────────────────
def create_bet(creator_id, amount, chat_id, expires_at):
    now = int(time.time())
    with _lock:
        c = _conn()
        cur = c.execute(
            "INSERT INTO bets(creator_id,amount,chat_id,created_at,expires_at) VALUES(?,?,?,?,?)",
            (creator_id,amount,chat_id,now,expires_at))
        bid = cur.lastrowid
        c.execute("UPDATE players SET balance=balance-? WHERE id=?", (amount,creator_id))
        c.commit(); c.close()
    return bid

def get_bet(bid):
    return q("SELECT * FROM bets WHERE id=?", (bid,), one=True)

def join_bet(bid, joiner_id, winner_id, amount, joiner_id_for_loss):
    tx([
        ("UPDATE bets SET status='done',joiner_id=?,winner_id=? WHERE id=?", (joiner_id,winner_id,bid)),
        ("UPDATE players SET balance=balance-? WHERE id=?", (amount,joiner_id)),
        ("UPDATE players SET balance=balance+?,wins=wins+1 WHERE id=?", (amount*2,winner_id)),
        ("UPDATE players SET losses=losses+1 WHERE id=?", (joiner_id_for_loss,)),
    ])

def cancel_bet(bid, creator_id, amount):
    tx([
        ("UPDATE bets SET status='cancelled' WHERE id=?", (bid,)),
        ("UPDATE players SET balance=balance+? WHERE id=?", (amount,creator_id)),
    ])

def expire_bet(bid, creator_id, amount):
    tx([
        ("UPDATE bets SET status='expired' WHERE id=?", (bid,)),
        ("UPDATE players SET balance=balance+? WHERE id=?", (amount,creator_id)),
    ])

# ─── Gift Code ───────────────────────
def use_code(code, uid):
    gc = q("SELECT * FROM gift_codes WHERE code=?", (code,), one=True)
    if not gc or gc['uses_left'] <= 0: return None, "invalid"
    used = q("SELECT 1 FROM code_uses WHERE code=? AND player_id=?", (code,uid), one=True)
    if used: return None, "used"
    tx([
        ("UPDATE gift_codes SET uses_left=uses_left-1 WHERE code=?", (code,)),
        ("INSERT INTO code_uses(code,player_id) VALUES(?,?)", (code,uid)),
        ("UPDATE players SET balance=balance+?,experience=experience+?,ruby=ruby+? WHERE id=?",
         (gc['coins'],gc['xp'],gc['ruby'],uid)),
    ])
    return gc, "ok"

# ─── Military ───────────────────────
def add_unit(uid, cat, utype):
    q("""INSERT INTO military_units(player_id,category,type,count,health) VALUES(?,?,?,1,100)
         ON CONFLICT(player_id,category,type) DO UPDATE SET count=count+1""",
      (uid,cat,utype), run=True)

def is_vip(p):
    if not p: return False
    return bool(p.get('vip')) and (p.get('vip_until',0) > time.time() or p.get('vip_until',0) == -1)
