# -*- coding: utf-8 -*-
"""
🎮 ULTIMATE TELEGRAM GAME BOT v3.0 PROFESSIONAL
══════════════════════════════════════════════════
ربات حرفه‌ای سطح شرکتی با قابلیت‌های پیشرفته

این فایل شامل:
- Core Imports & Setup
- Configuration & Logging  
- Force Join System
- User Management
- Database Integration
"""

import logging, random, string, time, asyncio, os, sys
from datetime import datetime, timedelta
from typing import Optional, Dict, List
from io import BytesIO

from telegram import Update, ChatMember, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters
)
from telegram.constants import ParseMode
from telegram.error import TelegramError

import database as db
from constants import *
from animations import *

# ═══════════════════════════════════════════════
# ⚙️  LOGGING SETUP - PROFESSIONAL
# ═══════════════════════════════════════════════
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    format='%(asctime)s | %(name)-12s | %(levelname)-8s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    level=logging.INFO,
    handlers=[
        logging.FileHandler("logs/bot.log", encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)
logger.info("=" * 60)
logger.info(" 🎮 ULTIMATE BOT v3.0 - STARTING UP")
logger.info("=" * 60)

# ═══════════════════════════════════════════════
# ⚙️  CONFIGURATION - ENTERPRISE LEVEL
# ═══════════════════════════════════════════════
TOKEN       = os.environ.get("BOT_TOKEN", "YOUR_BOT_TOKEN")
ADMIN_IDS   = list(map(int, os.environ.get("ADMIN_IDS", "123456789").split(",")))
MAIN_GROUP  = int(os.environ.get("MAIN_GROUP", "0"))
GROUP_LINK  = os.environ.get("GROUP_LINK", "https://t.me/your_group")
GROUP_NAME  = os.environ.get("GROUP_NAME", "گروه ما")

# Advanced Settings
ENABLE_ANALYTICS = os.environ.get("ENABLE_ANALYTICS", "true").lower() == "true"
ENABLE_BACKUP = os.environ.get("ENABLE_BACKUP", "true").lower() == "true"
RATE_LIMIT_ENABLED = os.environ.get("RATE_LIMIT_ENABLED", "true").lower() == "true"
MAX_REQUESTS_PER_MINUTE = int(os.environ.get("MAX_REQUESTS_PER_MINUTE", "20"))

# Rate Limiting Storage
user_request_counts = {}

def is_admin(uid): 
    return uid in ADMIN_IDS

def reset_rate_limit():
    """Reset rate limit counters every minute"""
    global user_request_counts
    user_request_counts.clear()

async def check_rate_limit(uid: int) -> bool:
    """Check if user exceeded rate limit"""
    if not RATE_LIMIT_ENABLED or is_admin(uid):
        return True
    
    current_count = user_request_counts.get(uid, 0)
    if current_count >= MAX_REQUESTS_PER_MINUTE:
        return False
    
    user_request_counts[uid] = current_count + 1
    return True

# ═══════════════════════════════════════════════
# 🎨  ASSETS LOADER
# ═══════════════════════════════════════════════
ASSETS = {}

def load_assets():
    """Load all assets into memory"""
    asset_files = [
        'welcome', 'win', 'win_vip', 'lose', 'lose_vip',
        'market', 'leaderboard', 'help', 'arsenal', 
        'bet', 'jobs', 'profile', 'admin'
    ]
    
    for name in asset_files:
        path = f'assets/{name}.jpg'
        if os.path.exists(path):
            with open(path, 'rb') as f:
                ASSETS[name] = f.read()
            logger.info(f"✅ Loaded asset: {name}.jpg")
        else:
            logger.warning(f"⚠️  Asset not found: {name}.jpg")
    
    logger.info(f"📦 Total assets loaded: {len(ASSETS)}")

def get_asset(name: str):
    """Get asset as BytesIO"""
    data = ASSETS.get(name)
    if not data:
        return None
    buf = BytesIO(data)
    buf.name = f"{name}.jpg"
    buf.seek(0)
    return buf

load_assets()

logger.info("✅ Core modules loaded successfully")
