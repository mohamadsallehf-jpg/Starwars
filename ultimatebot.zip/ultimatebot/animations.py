# -*- coding: utf-8 -*-
"""
انیمیشن‌ها و جلوه‌های بصری حرفه‌ای
"""
import random

# ══════════ انیمیشن لودینگ ══════════
LOADING_FRAMES = [
    "⏳ در حال بارگذاری",
    "⌛ در حال بارگذاری.",
    "⏳ در حال بارگذاری..",
    "⌛ در حال بارگذاری...",
]

# ══════════ انیمیشن موفقیت ══════════
SUCCESS_ANIMATIONS = [
    "✨ ⭐ 🌟 ✨",
    "🎉 🎊 🎈 🎁",
    "💎 💰 🏆 👑",
    "🔥 ⚡ 💫 ✨",
]

# ══════════ اسپارکل ══════════
def sparkle(text):
    """اضافه کردن جلوه درخشش"""
    sparkles = ["✨", "💫", "⭐", "🌟"]
    s = random.choice(sparkles)
    return f"{s} {text} {s}"

def intense_sparkle(text):
    """درخشش فوق‌العاده"""
    return f"✨⭐🌟✨ {text} ✨🌟⭐✨"

# ══════════ جعبه متن شیشه‌ای ══════════
def glass_box(title, *lines):
    """جعبه متنی شیشه‌ای"""
    width = max(len(title), max(len(l) for l in lines if l)) + 4
    border = "═" * width
    result = [
        f"╔{border}╗",
        f"║  {title.center(width-2)}  ║",
        f"╠{border}╣",
    ]
    for line in lines:
        if line:
            result.append(f"║  {line.ljust(width-2)}  ║")
    result.append(f"╚{border}╝")
    return "\n".join(result)

# ══════════ نوار پیشرفت پیشرفته ══════════
def progress_bar_advanced(current, maximum, length=15, style="default"):
    """نوار پیشرفت با استایل‌های مختلف"""
    styles = {
        "default": {"empty": "░", "filled": "█", "edges": ["[", "]"]},
        "blocks": {"empty": "▱", "filled": "▰", "edges": ["[", "]"]},
        "circles": {"empty": "○", "filled": "●", "edges": ["(", ")"]},
        "arrows": {"empty": "▹", "filled": "▸", "edges": ["«", "»"]},
        "fire": {"empty": "·", "filled": "🔥", "edges": ["[", "]"]},
        "hearts": {"empty": "♡", "filled": "♥", "edges": ["[", "]"]},
        "stars": {"empty": "☆", "filled": "★", "edges": ["[", "]"]},
    }
    
    st = styles.get(style, styles["default"])
    filled = int((current / maximum) * length) if maximum > 0 else 0
    bar = st["filled"] * filled + st["empty"] * (length - filled)
    pct = int((current / maximum) * 100) if maximum > 0 else 0
    
    return f"{st['edges'][0]}{bar}{st['edges'][1]} {pct}%"

# ══════════ متن رنگی مارک‌داون ══════════
def bold(text): return f"**{text}**"
def italic(text): return f"_{text}_"
def code(text): return f"`{text}`"
def code_block(text, lang=""): return f"```{lang}\n{text}\n```"
def link(text, url): return f"[{text}]({url})"

# ══════════ بنر ویژه ══════════
def victory_banner(name, prize):
    """بنر برنده شدن"""
    return f"""
╔═══════════════════════════════╗
║   🏆 تبریک به برنده! 🏆      ║
╠═══════════════════════════════╣
║                               ║
║   {name.center(27)}   ║
║                               ║
║   جایزه: {str(prize).center(19)}   ║
║                               ║
╚═══════════════════════════════╝
"""

def defeat_banner(name):
    """بنر باخت"""
    return f"""
╔═══════════════════════════════╗
║     😢 شانس نیاورد...        ║
╠═══════════════════════════════╣
║                               ║
║   {name.center(27)}   ║
║                               ║
║   دفعه بعد موفق می‌شی!       ║
║                               ║
╚═══════════════════════════════╝
"""

# ══════════ شمارش معکوس ══════════
def countdown_text(seconds):
    """متن شمارش معکوس"""
    if seconds > 60:
        mins = seconds // 60
        secs = seconds % 60
        return f"⏰ {mins}:{secs:02d}"
    elif seconds > 10:
        return f"⏱️ {seconds} ثانیه"
    else:
        return f"🔴 {seconds}!"

# ══════════ آیکون‌های وضعیت ══════════
STATUS_ICONS = {
    "online": "🟢",
    "offline": "⚫",
    "busy": "🔴",
    "away": "🟡",
    "vip": "👑",
    "admin": "⚜️",
    "banned": "🚫",
    "new": "🆕",
}

# ══════════ ایموجی‌های تصادفی ══════════
RANDOM_EMOJIS = {
    "money": ["💰", "💵", "💴", "💶", "💷", "🤑"],
    "gems": ["💎", "💠", "🔷", "🔹", "💙"],
    "weapons": ["🗡️", "⚔️", "🔫", "🏹", "💣"],
    "celebration": ["🎉", "🎊", "🎈", "🎁", "🥳"],
    "fire": ["🔥", "💥", "⚡", "✨", "💫"],
}

def random_emoji(category):
    """ایموجی تصادفی از یک دسته"""
    return random.choice(RANDOM_EMOJIS.get(category, ["✨"]))

# ══════════ لیست زیبا ══════════
def fancy_list(items, numbered=True):
    """لیست زیبا با شماره یا bullet"""
    if numbered:
        bullets = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        return "\n".join(f"{bullets[i] if i < 10 else '▪️'} {item}" 
                        for i, item in enumerate(items))
    else:
        return "\n".join(f"▪️ {item}" for item in items)

# ══════════ کارت اطلاعات ══════════
def info_card(title, data_dict):
    """کارت اطلاعاتی شیشه‌ای"""
    lines = [f"╔{'═' * 35}╗"]
    lines.append(f"║ {bold(title).center(42)} ║")
    lines.append(f"╠{'═' * 35}╣")
    for key, value in data_dict.items():
        lines.append(f"║ {key}: {value.rjust(32 - len(key))} ║")
    lines.append(f"╚{'═' * 35}╝")
    return "\n".join(lines)

# ══════════ انیمیشن حمله ══════════
ATTACK_ANIMATIONS = [
    "💥 بووووم!",
    "⚡ زااااپ!",
    "🔥 آتیش!",
    "💣 انفجار!",
    "🚀 شلیک!",
]

def attack_effect():
    """جلوه حمله تصادفی"""
    return random.choice(ATTACK_ANIMATIONS)

# ══════════ متن موج‌دار ══════════
def wave_text(text):
    """متن موج‌دار (برای تلگرام محدود است)"""
    wave_chars = "～〰️～〰️～"
    return f"{wave_chars} {text} {wave_chars}"
