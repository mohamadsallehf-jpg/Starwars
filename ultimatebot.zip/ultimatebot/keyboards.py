# -*- coding: utf-8 -*-
"""
🎨 Inline Keyboards - Glass UI Professional
همه کیبوردهای شیشه‌ای و حرفه‌ای
"""
from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Mkp

def btn(text, data=None, url=None):
    if url:
        return Btn(text, url=url)
    return Btn(text, callback_data=data)

def kb(*rows):
    return Mkp(list(rows))

def row(*btns):
    return list(btns)

# ══════════ منوی اصلی ══════════
def main_menu(is_admin=False, is_vip=False):
    rows = [
        row(btn("💰 حساب من", "profile"),      btn("🛒 فروشگاه", "shop")),
        row(btn("🎮 بازی‌ها", "games"),        btn("⚔️ شرط‌بندی", "betting")),
        row(btn("🎖️ زرادخانه", "arsenal"),     btn("🏆 رتبه‌بندی", "leaderboard")),
        row(btn("💼 مشاغل", "jobs"),           btn("👥 دعوت", "referral")),
        row(btn("📖 راهنما", "help"),          btn("⏱️ زمان", "cooldowns")),
    ]
    if is_admin:
        rows.append(row(btn("👨‍💼 پنل ادمین", "admin_panel")))
    return kb(*rows)

# ══════════ فروشگاه ══════════
def shop_menu():
    return kb(
        row(btn("🚀 موشک", "shop_missiles"),   btn("🛡️ دفاع", "shop_defenses")),
        row(btn("🚜 تانک", "shop_tanks"),      btn("✈️ جنگنده", "shop_fighters")),
        row(btn("🚢 کشتی", "shop_warships"),   btn("💺 پهپاد", "shop_drones")),
        row(btn("🔫 اسلحه", "shop_guns"),      btn("🏠 املاک", "shop_properties")),
        row(btn("🔙 بازگشت", "back_main")),
    )

# ══════════ بازی‌ها ══════════
def games_menu():
    return kb(
        row(btn("🎲 تاس", "game_tas"),        btn("🎰 اسلات", "game_slot")),
        row(btn("🎳 بولینگ", "game_bowling"),  btn("⚽ فوتبال", "game_football")),
        row(btn("🎯 دارت", "game_dart"),      btn("🏀 بسکتبال", "game_basketball")),
        row(btn("🔙 بازگشت", "back_main")),
    )

# ══════════ رتبه‌بندی ══════════
def leaderboard_menu():
    return kb(
        row(btn("💰 دارایی", "top_coin"),     btn("🎖️ سطح", "top_level")),
        row(btn("🎰 شرط", "top_bet"),         btn("🏅 برد", "top_wins")),
        row(btn("🔙 بازگشت", "back_main")),
    )

# ══════════ مشاغل ══════════
def jobs_menu():
    return kb(
        row(btn("🙏 گدا", "job_geda"),        btn("👮 پلیس", "job_police")),
        row(btn("💻 هکر 👑", "job_hacker"),    btn("🌿 ساقی 👑", "job_saghi")),
        row(btn("🔙 بازگشت", "back_main")),
    )

# ══════════ پنل ادمین ══════════
def admin_menu():
    return kb(
        row(btn("📊 آمار", "admin_stats"),    btn("👥 کاربران", "admin_users")),
        row(btn("💰 مالی", "admin_finance"),   btn("👑 VIP", "admin_vip")),
        row(btn("🎁 کد هدیه", "admin_gift"),   btn("📢 همگانی", "admin_broadcast")),
        row(btn("⚙️ تنظیمات", "admin_settings")),
    )

# ══════════ شرط دو نفره ══════════
def bet2_buttons(bet_id):
    return kb(
        row(btn("✅ پیوستن", f"bet2_join:{bet_id}")),
        row(btn("❌ لغو", f"bet2_cancel:{bet_id}")),
    )

def bet2_expired():
    return kb(row(btn("⌛ منقضی شد", "bet2_expired")))

# ══════════ تأیید ══════════
def confirm(action):
    return kb(
        row(btn("✅ تأیید", f"confirm:{action}"), 
            btn("❌ لغو", "cancel")),
    )

# ══════════ بازگشت ══════════
def back(to="back_main"):
    return kb(row(btn("🔙 بازگشت", to)))

# ══════════ لینک عضویت ══════════
def join_link(url, text):
    return kb(row(btn(f"🔗 {text}", url=url)))

# ══════════ Pagination ══════════
def pagination(current_page, total_pages, prefix):
    buttons = []
    if current_page > 1:
        buttons.append(btn("◀️ قبلی", f"{prefix}:{current_page-1}"))
    buttons.append(btn(f"{current_page}/{total_pages}", f"page_info"))
    if current_page < total_pages:
        buttons.append(btn("بعدی ▶️", f"{prefix}:{current_page+1}"))
    return kb(row(*buttons), row(btn("🔙 بازگشت", "back_main")))
